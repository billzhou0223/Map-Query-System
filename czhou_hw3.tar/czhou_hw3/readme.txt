ID: 00001070966
Name: Chicheng Zhou
Including files: ConnectToDB.java, GUI.java, MapPanel.java, Populate.java, createdb.sql, dropdb.sql
Run environment: Windows 8, Eclipse, JDK 1.7

If using Eclipse:
1. Put building.xy, photo.xy, photographer.xy and map.JPG under the directory of the project folder, put ConnectToDB.java, GUI.java, MapPanel.java, Populate.java in src folder.
2. Add ojdbc.jar and sdoapi.jar as external JARs.
3. Compile 
4. When run Populate class, right click on Poputale.java and choose run as-->run configurations, then go to Arguments tab, input building.xy photo.xy photographer.xy as threes parameters.
5. Run GUI class.

If using Windows command line:
cd <directory of czhou_hw3>
>javac -classpath .;..\..\..\ojdbc7.jar;..\..\..\sdoapi.jar Populate.java
>javac -classpath .;..\..\..\ojdbc7.jar;..\..\..\sdoapi.jar GUI.java
>java -classpath .;..\..\..\ojdbc7.jar;..\..\..\sdoapi.jar Populate building.xy photo.xy photographer.xy
>java -classpath .;..\..\..\ojdbc7.jar;..\..\..\sdoapi.jar GUI

