DROP TABLE temp;
DROP TABLE photo;
DROP TABLE photographer;
DROP TABLE building;


